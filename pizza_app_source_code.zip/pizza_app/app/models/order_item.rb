class OrderItem < ActiveRecord::Base



end
