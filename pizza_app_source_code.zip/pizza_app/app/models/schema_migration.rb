class SchemaMigration < ActiveRecord::Base



end
