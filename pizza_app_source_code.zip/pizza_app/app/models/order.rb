class Order < ActiveRecord::Base
    self.table_name = 'order'


end
